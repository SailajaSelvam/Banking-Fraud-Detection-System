import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

df = pd.read_csv("Bankfraud.csv")
numerical_cols = ['step', 'amount', 'oldbalanceOrg', 'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest']

os.makedirs("static/plots", exist_ok=True)

plt.figure(figsize=(6, 4))
sns.countplot(x='isFraud', data=df, palette='Set2')
plt.title("Fraud vs Non-Fraud")
plt.tight_layout()
plt.savefig("static/plots/fraud_distribution.png")
plt.close()

plt.figure(figsize=(8, 5))
sns.countplot(x='type', hue='isFraud', data=df, palette='Set1')
plt.title("Transaction Type vs Fraud")
plt.tight_layout()
plt.savefig("static/plots/type_vs_fraud.png")
plt.close()

plt.figure(figsize=(8, 5))
sns.histplot(data=df, x='amount', hue='isFraud', log_scale=True, bins=30, palette='coolwarm')
plt.title("Amount Distribution (Log Scale)")
plt.tight_layout()
plt.savefig("static/plots/amount_distribution.png")
plt.close()

plt.figure(figsize=(10, 6))
corr = df[numerical_cols + ['isFraud']].corr()
sns.heatmap(corr, annot=True, cmap='Blues', fmt=".2f")
plt.title("Correlation Matrix")
plt.tight_layout()
plt.savefig("static/plots/correlation_matrix.png")
plt.close()
