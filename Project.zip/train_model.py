import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from imblearn.over_sampling import SMOTE
import joblib


df = pd.read_csv("Bankfraud.csv")

df = df[['step', 'type', 'amount', 'oldbalanceOrg', 'newbalanceOrig',
         'oldbalanceDest', 'newbalanceDest', 'isFraud']]

X = df.drop("isFraud", axis=1)
y = df["isFraud"]

categorical_cols = ['type']
numerical_cols = ['step', 'amount', 'oldbalanceOrg', 'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest']

X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, test_size=0.2, random_state=42)

scaler = StandardScaler()
encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)

X_train_num = scaler.fit_transform(X_train[numerical_cols])
X_train_cat = encoder.fit_transform(X_train[categorical_cols])

print("\n--- Numerical Features After Scaling ---")
print(pd.DataFrame(X_train_num, columns=numerical_cols).head())

print("\n--- One-Hot Encoded 'type' Feature ---")
encoded_cat_cols = encoder.get_feature_names_out(categorical_cols)
print(pd.DataFrame(X_train_cat, columns=encoded_cat_cols).head())

X_train_processed = np.hstack([X_train_num, X_train_cat])
print(f"\nCombined Feature Matrix Shape: {X_train_processed.shape}")

smote = SMOTE(random_state=42)
X_train_resampled, y_train_resampled = smote.fit_resample(X_train_processed, y_train)

print(f"\nResampled Class Distribution:\n{pd.Series(y_train_resampled).value_counts()}")

model = LogisticRegression(max_iter=1000, random_state=42)
model.fit(X_train_resampled, y_train_resampled)

X_test_num = scaler.transform(X_test[numerical_cols])
X_test_cat = encoder.transform(X_test[categorical_cols])
X_test_processed = np.hstack([X_test_num, X_test_cat])

y_pred = model.predict(X_test_processed)
print("\n--- Classification Report ---")
print(classification_report(y_test, y_pred))

os.makedirs("model", exist_ok=True)
joblib.dump(model, "saved_model.pkl")
print("\nModel saved successfully as 'saved_model.pkl'")
