from flask import Flask, render_template, request
import numpy as np
import pandas as pd
import joblib
from sklearn.preprocessing import StandardScaler, OneHotEncoder

app = Flask(__name__)

model = joblib.load("saved_model.pkl")

scaler = StandardScaler()
encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)

dummy_df = pd.read_csv("Bankfraud.csv")
X_dummy = dummy_df[['step', 'type', 'amount', 'oldbalanceOrg', 'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest']]
scaler.fit(X_dummy[['step', 'amount', 'oldbalanceOrg', 'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest']])
encoder.fit(X_dummy[['type']])

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    try:
        step = float(request.form["step"])
        trans_type = request.form["type"]
        amount = float(request.form["amount"])
        oldbalanceOrg = float(request.form["oldbalanceOrg"])
        newbalanceOrig = float(request.form["newbalanceOrig"])
        oldbalanceDest = float(request.form["oldbalanceDest"])
        newbalanceDest = float(request.form["newbalanceDest"])

        input_num = scaler.transform([[step, amount, oldbalanceOrg, newbalanceOrig, oldbalanceDest, newbalanceDest]])
        input_cat = encoder.transform([[trans_type]])
        input_processed = np.hstack([input_num, input_cat])

        prediction = model.predict(input_processed)[0]
        label = "Fraudulent Transaction" if prediction == 1 else "Legitimate Transaction"

        return render_template("index.html", prediction=label)

    except Exception as e:
        return render_template("index.html", prediction=f"Error: {str(e)}")

if __name__ == "__main__":
    app.run(debug=True)
